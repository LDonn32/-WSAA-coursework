from flask import Flask, jsonify, request, send_from_directory
from studentDAO import StudentDAO
import requests

app = Flask(__name__, static_url_path="", static_folder="static")
dao = StudentDAO()

# ---------- STATIC ----------
@app.route("/")
def home():
    return send_from_directory("static", "index.html")

# ---------- CRUD API ----------
@app.route("/api/students", methods=["GET"])
def get_students():
    return jsonify(dao.get_all())

@app.route("/api/students/<int:id>", methods=["GET"])
def get_student(id):
    student = dao.find_by_id(id)
    return jsonify(student) if student else ("Not found", 404)

@app.route("/api/students", methods=["POST"])
def create_student():
    data = request.json
    dao.create(data)
    return jsonify({"status": "created"}), 201

@app.route("/api/students/<int:id>", methods=["PUT"])
def update_student(id):
    data = request.json
    dao.update(id, data)
    return jsonify({"status": "updated"})

@app.route("/api/students/<int:id>", methods=["DELETE"])
def delete_student(id):
    dao.delete(id)
    return jsonify({"status": "deleted"})

# ---------- THIRD PARTY API ----------
@app.route("/api/randomname")
def random_name():
    url = "https://randomuser.me/api/"
    response = requests.get(url).json()
    name = response["results"][0]["name"]
    return jsonify({"name": f"{name['first']} {name['last']}"})

if __name__ == "__main__":
    app.run()




























