from dbconfig import get_connection

class StudentDAO:

    def get_all(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM students")
        rows = cur.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def find_by_id(self, student_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM students WHERE id=?", (student_id,))
        row = cur.fetchone()
        conn.close()
        return dict(row) if row else None

    def create(self, student):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO students (name, address, email, course)
            VALUES (?, ?, ?, ?)
        """, (student["name"], student["address"], student["email"], student["course"]))
        conn.commit()
        conn.close()
        return True

    def update(self, student_id, student):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            UPDATE students
            SET name=?, address=?, email=?, course=?
            WHERE id=?
        """, (student["name"], student["address"], student["email"], student["course"], student_id))
        conn.commit()
        conn.close()
        return True

    def delete(self, student_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM students WHERE id=?", (student_id,))
        conn.commit()
        conn.close()
        return True


















